import React, { useEffect, useState } from "react";
import "../Style/Explore.css";
import { useNavigate } from "react-router-dom";

const Explore = () => {
  const [services, setServices] = useState([]);
  const [providers, setProviders] = useState([]); // Store providers
  const [searchQuery, setSearchQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [sortBy, setSortBy] = useState("rating");
  const navigate = useNavigate();

  // Fetch services and providers from the backend
  useEffect(() => {
    // Fetch services
    fetch("http://localhost:5000/api/services")
      .then((response) => response.json())
      .then((data) => setServices(data.services || []))
      .catch((error) => console.error("Error fetching services:", error));

    // Fetch providers
    fetch("http://localhost:5000/api/providers")
      .then((response) => response.json())
      .then((data) => setProviders(data.providers || []))
      .catch((error) => console.error("Error fetching providers:", error));
  }, []);

  // Handle click on "Book Now" button
  const handleServiceClick = (serviceName) => {
    if (!serviceName) return;
    navigate(`/book/${encodeURIComponent(serviceName)}`);
  };

  // Handle click on "View Provider" button
  const handleProviderClick = (serviceName) => {
    if (!serviceName) return;

    // Find all providers who offer this service
    const providersForService = providers.filter((provider) =>
      provider.services.includes(serviceName)
    );

    if (providersForService.length > 0) {
      // Navigate to the providers-for-service page with the service name and providers list
      navigate(`/providers-for-service/${encodeURIComponent(serviceName)}`, {
        state: { providers: providersForService }, // Pass providers as state
      });
    } else {
      console.error("No providers found for service:", serviceName);
      alert("No providers found for this service.");
    }
  };

  // Filter services based on search query and category
  const filteredServices = services
    .filter((service) =>
      service.name.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .filter((service) =>
      category === "All" ? true : service.category === category
    );

  // Sort services based on rating or price
  const sortedServices = [...filteredServices].sort((a, b) =>
    sortBy === "rating" ? b.rating - a.rating : a.price - b.price
  );

  return (
    <div className="explore-container">
      <h2>Explore Services</h2>
      <input
        type="text"
        placeholder="Search services..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="search-bar"
      />
      <select onChange={(e) => setCategory(e.target.value)}>
        <option value="All">All Categories</option>
        {[...new Set(services.map((s) => s.category))].map((cat) => (
          <option key={cat} value={cat}>
            {cat}
          </option>
        ))}
      </select>
      <select onChange={(e) => setSortBy(e.target.value)}>
        <option value="rating">Sort by Rating</option>
        <option value="price">Sort by Price</option>
      </select>
      {/* Navigate to Providers Page */}
      <button
        className="view-providers-btn"
        onClick={() => navigate("/providers")}
      >
        View All Providers
      </button>
      <div className="services-list">
        {sortedServices.map((service) => (
          <div key={service._id} className="service-card">
            <h3>{service.name}</h3>
            <p>Category: {service.category}</p>
            <p>Rating: {service.rating}</p>
            <p>Price: ${service.price}</p>
            <button onClick={() => handleServiceClick(service.name)}>
              Book Now
            </button>
            {/* ✅ "View Provider" button */}
            <button onClick={() => handleProviderClick(service.name)}>
              View Provider
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Explore;
