import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../Style/EmergencyServices.css";

const EmergencyServices = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedService, setSelectedService] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [submittedData, setSubmittedData] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    issue: "",
    location: "",
  });

  const navigate = useNavigate();

  // Fetch emergency services from the backend
  useEffect(() => {
    fetch("http://localhost:5000/api/emergency-services")
      .then((response) => response.json())
      .then((data) => {
        setServices(data || []); // Ensure data is set correctly
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching emergency services:", error);
        setLoading(false);
      });
  }, []);

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle form submission for specific service request
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Data Being Submitted:", formData); // Debugging line

    fetch("http://localhost:5000/api/request-service", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        console.log("API Response:", data); // Debugging line

        // Store the submitted data for the pop-up
        setSubmittedData(formData);
        console.log("Submitted Data Stored:", formData); // Debugging line

        // Reset the form
        setFormData({ name: "", phone: "", issue: "", location: "" });
        console.log("Form Reset Successfully"); // Debugging line

        // Show confirmation pop-up
        setShowConfirmation(true);
        console.log("Pop-Up Shown: true"); // Debugging line

        // Delay navigation to allow pop-up visibility
        setTimeout(() => {
          setShowConfirmation(false);
          console.log("Pop-Up Closed: false"); // Debugging line
          navigate("/home"); // Navigate after pop-up closes
        }, 3000);
      })
      .catch((error) => {
        console.error("Error submitting request:", error);
        alert("Failed to submit the request. Please try again.");
      });
  };

  return (
    <div className="emergency-services-container">
      <h2>Emergency Services</h2>
      {loading ? (
        <p>Loading emergency services...</p>
      ) : services.length > 0 ? (
        <div className="services-list">
          {services.map((service) => (
            <div key={service._id} className="service-card">
              <h3>{service.name}</h3>
              <p>Location: {service.location}</p>
              <p>Price: ${service.price}</p>
              <p>Contact: {service.contact}</p> {/* Fixed property name */}
              <button onClick={() => setSelectedService(service)}>
                View Details
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p>No emergency services available.</p>
      )}

      {/* Form for specific service request */}
      <div className="service-request-form">
        <h3>Request a Specific Service</h3>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            value={formData.name}
            onChange={handleInputChange}
            required
          />
          <input
            type="tel"
            name="phone"
            placeholder="Your Phone Number"
            value={formData.phone}
            onChange={handleInputChange}
            required
          />
          <input
            type="text"
            name="issue"
            placeholder="Describe Your Issue"
            value={formData.issue}
            onChange={handleInputChange}
            required
          />
          <input
            type="text"
            name="location"
            placeholder="Your Location"
            value={formData.location}
            onChange={handleInputChange}
            required
          />
          <button className="btn-sb" type="submit">
            Submit Request
          </button>
        </form>
      </div>

      {/* Pop-up for service details */}
      {selectedService && (
        <div className="popup-overlay">
          <div className="popup-content">
            <h3>{selectedService.name}</h3>
            <p>Location: {selectedService.location}</p>
            <p>Price: ${selectedService.price}</p>
            <p>Contact: {selectedService.contact}</p>
            <button onClick={() => setSelectedService(null)}>Close</button>
          </div>
        </div>
      )}

      {/* Pop-up for Confirmation Message */}
      {showConfirmation && submittedData && (
        <div className="popup-overlay">
          <div className="popup-content">
            <h3>Request Submitted</h3>
            <p>Your request has been successfully submitted.</p>
            <p>Here are the details:</p>
            <ul>
              <li>Name: {submittedData.name}</li>
              <li>Phone: {submittedData.phone}</li>
              <li>Issue: {submittedData.issue}</li>
              <li>Location: {submittedData.location}</li>
            </ul>
            <p>A provider will contact you within 15 minutes.</p>
            <button onClick={() => setShowConfirmation(false)}>OK</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmergencyServices;
