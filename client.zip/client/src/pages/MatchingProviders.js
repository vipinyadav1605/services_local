import React from "react";
import { useLocation } from "react-router-dom";
import style from "../Style/MatchingProviders.module.css";

const MatchingProviders = () => {
  const location = useLocation();
  const { providers } = location.state || { providers: [] };

  return (
    <div className={style.providersContainer}>
      <h2>Matching Providers</h2>
      {providers.length === 0 ? (
        <p>No providers found for your requirements.</p>
      ) : (
        <ul>
          {providers.map((provider) => (
            <li key={provider._id} className={style.providerCard}>
              <h3>{provider.name}</h3>
              <p>Price: ${provider.price}</p>
              <p>Location: {provider.location}</p>
              <p>Skills: {provider.skills.join(", ")}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default MatchingProviders;
