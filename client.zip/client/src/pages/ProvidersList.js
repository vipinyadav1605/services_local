import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"; // For navigation
import "../Style/ProvidersList.css"; // Import your CSS file

const ProvidersList = () => {
  const [providers, setProviders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedProvider, setSelectedProvider] = useState(null); // Track the selected provider
  const navigate = useNavigate(); // Hook for navigation

  useEffect(() => {
    fetch("http://localhost:5000/api/providers")
      .then((response) => response.json())
      .then((data) => {
        console.log("Fetched Providers:", data.providers); // Debugging line
        setProviders(data.providers || []);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching providers:", error);
        setLoading(false);
      });
  }, []);

  // Handle click on "View Details" button
  const handleViewDetails = (providerId) => {
    console.log("View Details Button Clicked, Provider ID:", providerId); // Debugging line
    if (!providerId) {
      console.error("Provider ID is missing.");
      return;
    }

    const provider = providers.find((p) => p._id === providerId);
    console.log("Selected Provider:", provider); // Debugging line

    if (provider) {
      // Show provider details in an alert
      alert(
        `Provider Details:\n\nName: ${provider.name}\nExperience: ${
          provider.experience ?? "N/A"
        } years\nRating: ${provider.rating}`
      );
    } else {
      console.error("Provider not found for ID:", providerId);
    }
  };

  // Handle click on "Book Now" button
  const handleBookNow = (providerId) => {
    console.log("Book Now Button Clicked, Provider ID:", providerId); // Debugging line
    if (!providerId) {
      console.error("Provider ID is missing.");
      return;
    }

    const provider = providers.find((p) => p._id === providerId);
    console.log("Selected Provider:", provider); // Debugging line

    if (provider) {
      // Save booking details to localStorage
      const bookingDetails = {
        providerId: provider._id,
        providerName: provider.name,
        service: provider.service, // Assuming the provider object has a `service` field
        bookedAt: new Date().toLocaleString(),
      };
      localStorage.setItem("bookingDetails", JSON.stringify(bookingDetails));

      // Redirect to the booking page
      navigate("/booking");
    } else {
      console.error("Provider not found for ID:", providerId);
    }
  };

  // Close the pop-up
  const closePopup = () => {
    setSelectedProvider(null);
  };

  return (
    <div className="title-provide">
      <h2 className="title-this">Available Providers</h2>
      <div className="providers-container">
        {loading ? (
          <p>Loading providers...</p>
        ) : providers.length > 0 ? (
          providers.map((provider) => (
            <div key={provider._id} className="provider-card">
              <h3>{provider.name}</h3>
              <p>Experience: {provider.experience ?? "N/A"} years</p>
              <p>Rating: {provider.rating}</p>
              <button onClick={() => handleViewDetails(provider._id)}>
                View Details
              </button>
              <button onClick={() => handleBookNow(provider._id)}>
                Book Now!
              </button>
            </div>
          ))
        ) : (
          <p>No providers available.</p>
        )}

        {/* Pop-up for provider details */}
        {selectedProvider && (
          <div className="popup-overlay">
            <div className="popup-content">
              <h3>{selectedProvider.name}</h3>
              <p>Experience: {selectedProvider.experience ?? "N/A"} years</p>
              <p>Rating: {selectedProvider.rating}</p>
              <button onClick={closePopup}>Close</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProvidersList;
