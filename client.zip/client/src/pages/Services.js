import React from "react";
import "../Style/Services.css"; // Import CSS for advanced styling
import {
  FaWrench,
  FaPlug,
  FaPaintBrush,
  FaLaptopCode,
  FaCar,
  FaHammer,
  FaBroom,
  FaDog,
  FaTruck,
  FaHeartbeat,
  FaHome,
  FaUserNurse,
  FaUtensils,
  FaBookOpen,
  FaMusic,
} from "react-icons/fa";
import { useNavigate } from "react-router-dom"; // ✅ Import this

const services = [
  { name: "Plumbing", icon: <FaWrench />, rating: 4.5, reviews: 120 },
  { name: "Electrician", icon: <FaPlug />, rating: 4.7, reviews: 95 },
  { name: "Painting", icon: <FaPaintBrush />, rating: 4.6, reviews: 80 },
  {
    name: "Web Development",
    icon: <FaLaptopCode />,
    rating: 4.9,
    reviews: 150,
  },
  { name: "Car Repair", icon: <FaCar />, rating: 4.4, reviews: 110 },
  { name: "Carpentry", icon: <FaHammer />, rating: 4.3, reviews: 90 },
  { name: "House Cleaning", icon: <FaBroom />, rating: 4.8, reviews: 130 },
  { name: "Pet Grooming", icon: <FaDog />, rating: 4.7, reviews: 100 },
  { name: "Moving Services", icon: <FaTruck />, rating: 4.5, reviews: 85 },
  { name: "Healthcare", icon: <FaHeartbeat />, rating: 4.9, reviews: 140 },
  { name: "Home Security", icon: <FaHome />, rating: 4.6, reviews: 75 },
  { name: "Nursing", icon: <FaUserNurse />, rating: 4.7, reviews: 90 },
  { name: "Catering", icon: <FaUtensils />, rating: 4.8, reviews: 125 },
  { name: "Tutoring", icon: <FaBookOpen />, rating: 4.6, reviews: 105 },
  { name: "Music Lessons", icon: <FaMusic />, rating: 4.9, reviews: 95 },
];

const Services = () => {
  const navigate = useNavigate(); // Hook for navigation

  // const handleBookNow = (serviceName) => {
  //   navigate(`/book/${serviceName}`); // Navigate to booking page with service name
  // };
  return (
    <div className="services-container">
      <h2 className="services-title">Available Services</h2>
      <div className="services-grid">
        {services.map((service, index) => (
          <div key={index} className="service-card">
            <div className="service-icon">{service.icon}</div>
            <h3 className="service-name">{service.name}</h3>
            <p className="service-rating">
              ⭐ {service.rating} ({service.reviews} reviews)
            </p>
            <button
              className="book-now-btn"
              onClick={() => navigate(`/book/${service.name}`)}
            >
              Book Now
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;
