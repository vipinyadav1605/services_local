// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import "../Style/CashOnService.module.css"; // Import CSS for this component

// const CashOnService = () => {
//   const [formData, setFormData] = useState({
//     panCard: "",
//     aadharCard: "",
//     mobile1: "",
//     mobile2: "",
//     photo: null,
//   });
//   const [loading, setLoading] = useState(false);
//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     const { name, value, files } = e.target;
//     if (name === "photo") {
//       setFormData({ ...formData, [name]: files[0] });
//     } else {
//       setFormData({ ...formData, [name]: value });
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setLoading(true);

//     const formDataToSend = new FormData();
//     formDataToSend.append("panCard", formData.panCard);
//     formDataToSend.append("aadharCard", formData.aadharCard);
//     formDataToSend.append("mobile1", formData.mobile1);
//     formDataToSend.append("mobile2", formData.mobile2);
//     formDataToSend.append("photo", formData.photo);

//     try {
//       const response = await fetch(
//         "http://localhost:5000/api/cash-on-service",
//         {
//           method: "POST",
//           body: formDataToSend,
//         }
//       );

//       if (response.ok) {
//         alert("Details submitted successfully!");
//         navigate("/"); // Redirect to home or another page
//       } else {
//         alert("Failed to submit details. Please try again.");
//       }
//     } catch (error) {
//       console.error("Error submitting details:", error);
//       alert("An error occurred. Please try again.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="cash-on-service-container">
//       <h2>Cash on Service Details</h2>
//       <form onSubmit={handleSubmit}>
//         <label>
//           PAN Card:
//           <input
//             type="text"
//             name="panCard"
//             value={formData.panCard}
//             onChange={handleChange}
//             required
//           />
//         </label>
//         <label>
//           Aadhar Card:
//           <input
//             type="text"
//             name="aadharCard"
//             value={formData.aadharCard}
//             onChange={handleChange}
//             required
//           />
//         </label>
//         <label>
//           Mobile Number 1:
//           <input
//             type="text"
//             name="mobile1"
//             value={formData.mobile1}
//             onChange={handleChange}
//             required
//           />
//         </label>
//         <label>
//           Mobile Number 2:
//           <input
//             type="text"
//             name="mobile2"
//             value={formData.mobile2}
//             onChange={handleChange}
//             required
//           />
//         </label>
//         <label>
//           Upload Photo:
//           <input
//             type="file"
//             name="photo"
//             onChange={handleChange}
//             accept="image/*"
//             required
//           />
//         </label>
//         <button type="submit" disabled={loading}>
//           {loading ? "Submitting..." : "Submit"}
//         </button>
//       </form>
//     </div>
//   );
// };

// export default CashOnService;

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import styles from "../Style/CashOnService.module.css"; // Import CSS Module

const CashOnService = () => {
  const [formData, setFormData] = useState({
    panCard: "",
    aadharCard: "",
    mobile1: "",
    mobile2: "",
    photo: null,
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "photo") {
      setFormData({ ...formData, [name]: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const formDataToSend = new FormData();
    formDataToSend.append("panCard", formData.panCard);
    formDataToSend.append("aadharCard", formData.aadharCard);
    formDataToSend.append("mobile1", formData.mobile1);
    formDataToSend.append("mobile2", formData.mobile2);
    formDataToSend.append("photo", formData.photo);

    try {
      const response = await fetch(
        "http://localhost:5000/api/cash-on-service",
        {
          method: "POST",
          body: formDataToSend,
        }
      );

      if (response.ok) {
        alert("Details submitted successfully!");
        navigate("/");
      } else {
        alert("Failed to submit details. Please try again.");
      }
    } catch (error) {
      console.error("Error submitting details:", error);
      alert("An error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.cashOnServiceContainer}>
      <h2>Cash on Service Details</h2>
      <form onSubmit={handleSubmit} className={styles.form}>
        <label className={styles.label}>
          PAN Card:
          <input
            type="text"
            name="panCard"
            value={formData.panCard}
            onChange={handleChange}
            required
            className={styles.input}
          />
        </label>
        <label className={styles.label}>
          Aadhar Card:
          <input
            type="text"
            name="aadharCard"
            value={formData.aadharCard}
            onChange={handleChange}
            required
            className={styles.input}
          />
        </label>
        <label className={styles.label}>
          Mobile Number 1:
          <input
            type="text"
            name="mobile1"
            value={formData.mobile1}
            onChange={handleChange}
            required
            className={styles.input}
          />
        </label>
        <label className={styles.label}>
          Mobile Number 2:
          <input
            type="text"
            name="mobile2"
            value={formData.mobile2}
            onChange={handleChange}
            required
            className={styles.input}
          />
        </label>
        <label className={styles.label}>
          Upload Your Photo:
          <input
            type="file"
            name="photo"
            onChange={handleChange}
            accept="image/*"
            required
            className={styles.fileInput}
          />
        </label>
        <button
          type="submit"
          disabled={loading}
          className={styles.submitButton}
        >
          {loading ? "Submitting..." : "Submit"}
        </button>
      </form>
    </div>
  );
};

export default CashOnService;
