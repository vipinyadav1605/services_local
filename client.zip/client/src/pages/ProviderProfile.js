import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const ProviderProfile = () => {
  const { providerId } = useParams();
  const [provider, setProvider] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`http://localhost:5000/api/providers/${providerId}`)
      .then((response) => response.json())
      .then((data) => {
        setProvider(data.provider);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching provider details:", error);
        setLoading(false);
      });
  }, [providerId]);

  if (loading) return <p>Loading provider details...</p>;
  if (!provider) return <p>Provider not found.</p>;

  return (
    <div>
      <h2>{provider.name}</h2>
      <p>Experience: {provider.experience} years</p>
      <p>Rating: {provider.rating}</p>
      <p>Email: {provider.email}</p>
      <p>Phone: {provider.phone}</p>
      <p>Specialty: {provider.specialty}</p>
      {/* Add more details as needed */}
    </div>
  );
};

export default ProviderProfile;
