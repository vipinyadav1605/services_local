import React, { useState } from "react";
import "../Style/ManageServices.css";

const dummyServices = [
  {
    id: 1,
    title: "Home Cleaning",
    category: "Cleaning",
    price: 1500,
    available: true,
    location: "Delhi",
    image: "https://via.placeholder.com/100",
  },
  {
    id: 2,
    title: "Plumbing Repair",
    category: "Plumbing",
    price: 2000,
    available: false,
    location: "Mumbai",
    image: "https://via.placeholder.com/100",
  },
  {
    id: 3,
    title: "AC Service",
    category: "AC Repair",
    price: 2500,
    available: true,
    location: "Bangalore",
    image: "https://via.placeholder.com/100",
  },
];

const ManageServices = () => {
  const [services, setServices] = useState(dummyServices);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");

  const toggleAvailability = (id) => {
    setServices((prevServices) =>
      prevServices.map((service) =>
        service.id === id
          ? { ...service, available: !service.available }
          : service
      )
    );
  };

  const handleDelete = (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this service?"
    );
    if (confirmDelete) {
      setServices(services.filter((service) => service.id !== id));
    }
  };

  const filteredServices = services.filter((service) => {
    return (
      service.title.toLowerCase().includes(search.toLowerCase()) &&
      (category ? service.category === category : true)
    );
  });

  return (
    <div className="manage-services-page">
      <div className="manage-services-container">
        <h2>Manage Services</h2>
        <p>Edit or remove your listed services.</p>

        {/* Search & Filter */}
        <div className="filter-container">
          <input
            type="text"
            placeholder="Search service..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="search-input"
          />

          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="filter-select"
          >
            <option value="">All Categories</option>
            <option value="Cleaning">Cleaning</option>
            <option value="Plumbing">Plumbing</option>
            <option value="AC Repair">AC Repair</option>
            <option value="Home Repair">Home Repair</option>
            <option value="Beauty & Salon">Beauty & Salon</option>
          </select>
        </div>

        {/* Services List */}
        <div className="services-list">
          {filteredServices.length > 0 ? (
            filteredServices.map((service) => (
              <div key={service.id} className="service-card">
                <img
                  src={service.image}
                  alt={service.title}
                  className="service-image"
                />
                <div className="service-info">
                  <h3>{service.title}</h3>
                  <p>Category: {service.category}</p>
                  <p>Price: ₹{service.price}</p>
                  <p>Location: {service.location}</p>
                  <p>
                    Status: {service.available ? "Available" : "Unavailable"}
                  </p>
                </div>
                <div className="service-actions">
                  <button
                    className="toggle-btn"
                    onClick={() => toggleAvailability(service.id)}
                  >
                    {service.available ? "Disable" : "Enable"}
                  </button>
                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(service.id)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p className="no-services">No services found.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ManageServices;
