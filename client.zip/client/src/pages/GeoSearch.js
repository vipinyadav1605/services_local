import React, { useState, useEffect } from "react";
import { GoogleMap, LoadScript, Marker } from "@react-google-maps/api";
import "../Style/GeoSearch.css";

const GeoSearch = () => {
  const [location, setLocation] = useState(null);
  const [error, setError] = useState("");
  const [serviceProviders, setServiceProviders] = useState([]);

  // Fetch user location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          setError("Geolocation is not supported or permission denied.");
        }
      );
    } else {
      setError("Geolocation is not supported by this browser.");
    }

    // Mock service providers (fetch from backend in real implementation)
    setServiceProviders([
      { id: 1, name: "Electrician", lat: 28.6139, lng: 77.209 },
      { id: 2, name: "Plumber", lat: 28.61, lng: 77.2 },
    ]);
  }, []);

  return (
    <div className="geo-container">
      <h2>Find Services Near You 📍</h2>

      {error && <p className="error">{error}</p>}

      {location && (
        <LoadScript googleMapsApiKey="YOUR_GOOGLE_MAPS_API_KEY">
          <GoogleMap mapContainerClassName="map" center={location} zoom={14}>
            <Marker position={location} label="You" />

            {serviceProviders.map((provider) => (
              <Marker
                key={provider.id}
                position={{ lat: provider.lat, lng: provider.lng }}
                label={provider.name}
              />
            ))}
          </GoogleMap>
        </LoadScript>
      )}
    </div>
  );
};

export default GeoSearch;
