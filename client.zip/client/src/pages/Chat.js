import React, { useState, useEffect, useRef } from "react";
import { FaPaperPlane, FaSmile, FaMoon, FaSun } from "react-icons/fa";
import { IoCheckmark, IoCheckmarkDone } from "react-icons/io5";
import "../Style/Chat.css";

const Chat = () => {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const [darkMode, setDarkMode] = useState(false);
  const [typing, setTyping] = useState(false);
  const chatEndRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (message.trim() === "") return;

    setMessages([...messages, { text: message, sender: "user", seen: false }]);
    setMessage("");

    // Simulate a bot response with a delay
    setTyping(true);
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        { text: "Hello! How can I help you?", sender: "bot", seen: true },
      ]);
      setTyping(false);
    }, 2000);
  };

  return (
    <div className="chat-page">
      <div className={`chat-container ${darkMode ? "dark" : ""}`}>
        {/* Header with Dark Mode Toggle */}
        <div className="chat-header">
          <h2>Chat Support</h2>
          <button
            className="mode-toggle"
            onClick={() => setDarkMode(!darkMode)}
          >
            {darkMode ? <FaSun /> : <FaMoon />}
          </button>
        </div>

        {/* Chat History */}
        <div className="chat-history">
          {messages.map((msg, index) => (
            <div key={index} className={`message ${msg.sender}`}>
              <span>{msg.text}</span>
              <span className="timestamp">10:45 AM</span>
              {msg.sender === "user" &&
                (msg.seen ? (
                  <IoCheckmarkDone className="read" />
                ) : (
                  <IoCheckmark />
                ))}
            </div>
          ))}
          {typing && <div className="typing-indicator">Bot is typing...</div>}
          <div ref={chatEndRef}></div>
        </div>

        {/* Message Input Section */}
        <div className="chat-input">
          <button className="emoji-button">
            <FaSmile />
          </button>
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type a message..."
          />
          <button className="send-button" onClick={sendMessage}>
            <FaPaperPlane />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chat;
