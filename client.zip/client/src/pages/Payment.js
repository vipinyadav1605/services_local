import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate for navigation
import "../Style/Payment.css";

const Payment = () => {
  const [paymentMethod, setPaymentMethod] = useState("");
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate(); // Hook for navigation

  const handlePayment = () => {
    if (!paymentMethod) {
      alert("Please select a payment method!");
      return;
    }

    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      setSuccess(true);
    }, 2000);
  };

  // Handle "Cash on Service" button click
  const handleCashOnService = () => {
    navigate("/cash-on-service"); // Redirect to the Cash on Service page
  };

  return (
    <div className="payment-container">
      <h2>Secure Payment</h2>

      {!success ? (
        <>
          <p>Select Payment Method:</p>
          <div className="payment-options">
            <button
              className={`payment-btn ${
                paymentMethod === "card" ? "selected" : ""
              }`}
              onClick={() => setPaymentMethod("card")}
            >
              Credit/Debit Card
            </button>
            <button
              className={`payment-btn ${
                paymentMethod === "upi" ? "selected" : ""
              }`}
              onClick={() => setPaymentMethod("upi")}
            >
              UPI
            </button>
            <button
              className={`payment-btn ${
                paymentMethod === "netbanking" ? "selected" : ""
              }`}
              onClick={() => setPaymentMethod("netbanking")}
            >
              Net Banking
            </button>
            <button
              className={`payment-btn ${
                paymentMethod === "cash" ? "selected" : ""
              }`}
              onClick={handleCashOnService}
            >
              Cash on Service
            </button>
          </div>

          <button
            className="pay-now"
            onClick={handlePayment}
            disabled={processing}
          >
            {processing ? "Processing..." : "Pay Now"}
          </button>
        </>
      ) : (
        <div className="payment-success">
          <h3>Payment Successful! 🎉</h3>
          <p>Your transaction has been completed.</p>
        </div>
      )}
    </div>
  );
};

export default Payment;
