import React from "react";
import { useLocation, useParams } from "react-router-dom";
import "../Style/ProvidersForService.css";
const ProvidersForService = () => {
  const { serviceName } = useParams(); // Get the service name from the URL
  const location = useLocation();
  const providers = location.state?.providers || []; // Get providers from state

  return (
    <div className="providers-for-service-container">
      <h2>Providers for {decodeURIComponent(serviceName)}</h2>
      {providers.length > 0 ? (
        <div className="providers-list">
          {providers.map((provider) => (
            <div key={provider._id} className="provider-card">
              <h3>{provider.name}</h3>
              <p>Experience: {provider.experience} years</p>
              <p>Rating: {provider.rating}</p>
              {/* Add more provider details here */}
            </div>
          ))}
        </div>
      ) : (
        <p>No providers found for this service.</p>
      )}
    </div>
  );
};

export default ProvidersForService;
