import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../Style/Profile.css";

const Profile = () => {
  const [user, setUser] = useState(() => {
    const savedUser = JSON.parse(localStorage.getItem("user"));
    return (
      savedUser || {
        name: "Vipin Yadav",
        email: "vipinyadav@example.com",
        phone: "+91 9876543210",
        address: "123, Main Street, Delhi, India",
        bio: "Full-stack developer passionate about MERN stack.",
        profileImage: "/images/profile.jpg", // Ensure this image exists
      }
    );
  });

  const [editMode, setEditMode] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login"); // Redirect immediately
    }
  }, [navigate]);

  useEffect(() => {
    localStorage.setItem("user", JSON.stringify(user));
  }, [user]);

  const handleInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setUser((prevUser) => ({ ...prevUser, profileImage: imageUrl }));
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    localStorage.removeItem("role");
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div className={`profile-container ${darkMode ? "dark-mode" : ""}`}>
      <header>
        <h1>User Profile</h1>
        <button
          className="dark-mode-btn"
          onClick={() => setDarkMode(!darkMode)}
        >
          {darkMode ? "☀️ Light Mode" : "🌙 Dark Mode"}
        </button>
      </header>

      <section className="profile-section">
        <label htmlFor="imageUpload" className="profile-img-label">
          <img
            src={user.profileImage}
            alt="Profile"
            className="profile-img"
            onError={(e) => {
              e.target.src = "/images/fallback.jpg"; // Local fallback
              e.target.onerror = null; // Prevent infinite loop
            }}
          />
          <input
            type="file"
            id="imageUpload"
            accept="image/*"
            onChange={handleImageUpload}
            style={{ display: "none" }}
          />
        </label>

        {editMode ? (
          <article className="profile-form">
            <input
              type="text"
              name="name"
              value={user.name}
              onChange={handleInputChange}
            />
            <input
              type="email"
              name="email"
              value={user.email}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="phone"
              value={user.phone}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="address"
              value={user.address}
              onChange={handleInputChange}
            />
            <textarea
              name="bio"
              value={user.bio}
              onChange={handleInputChange}
            ></textarea>
            <button className="save-btn" onClick={() => setEditMode(false)}>
              Save Changes
            </button>
          </article>
        ) : (
          <article className="profile-details">
            <h2>Name: {user.name}</h2>
            <p>
              <strong>Email:</strong> {user.email}
            </p>
            <p>
              <strong>Phone:</strong> {user.phone}
            </p>
            <p>
              <strong>Address:</strong> {user.address}
            </p>
            <p className="bio">
              <strong>Bio:</strong> {user.bio}
            </p>
            <button className="edit-btn" onClick={() => setEditMode(true)}>
              Edit Profile
            </button>
            <button
              className="logout-btn"
              onClick={() => setShowLogoutModal(true)}
            >
              🚪 Logout
            </button>
          </article>
        )}
      </section>

      {showLogoutModal && (
        <div className="logout-modal">
          <div className="modal-content">
            <p>Are you sure you want to log out?</p>
            <button
              className="cancel-btn"
              onClick={() => setShowLogoutModal(false)}
            >
              Cancel
            </button>
            <button className="ok-btn" onClick={handleLogout}>
              OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;
