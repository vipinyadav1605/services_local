import React, { useEffect, useState } from "react";
import axios from "axios";
import "../Style/Home.css";
import { useNavigate } from "react-router-dom";
import {
  FaWrench,
  FaPlug,
  FaPaintBrush,
  FaLaptopCode,
  FaCar,
  FaHammer,
  FaBroom,
  FaDog,
  FaTruck,
  FaHeartbeat,
  FaHome,
  FaUserNurse,
  FaUtensils,
  FaBookOpen,
  FaMusic,
  FaTools, // Default fallback icon
} from "react-icons/fa";

// Mapping service names to icons (keys in lowercase for consistency)
const serviceIcons = {
  plumbing: <FaWrench />,
  electrician: <FaPlug />,
  painting: <FaPaintBrush />,
  "web development": <FaLaptopCode />,
  "car repair": <FaCar />,
  carpentry: <FaHammer />,
  "house cleaning": <FaBroom />,
  "pet grooming": <FaDog />,
  "moving services": <FaTruck />,
  healthcare: <FaHeartbeat />,
  "home security": <FaHome />,
  nursing: <FaUserNurse />,
  catering: <FaUtensils />,
  tutoring: <FaBookOpen />,
  "music lessons": <FaMusic />,
};

const Home = () => {
  const [services, setServices] = useState([]);
  const [search, setSearch] = useState("");
  const [filteredServices, setFilteredServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedService, setSelectedService] = useState(null);
  const [category, setCategory] = useState("All");
  const [sortOption, setSortOption] = useState("default");
  const [location, setLocation] = useState("All");
  const [favorites, setFavorites] = useState([]);
  const navigate = useNavigate();

  // Fetch services from API
  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/services");
        console.log("API Response:", response.data); // Debugging

        if (response.data && Array.isArray(response.data.services)) {
          setServices(response.data.services);
          setFilteredServices(response.data.services);
        } else {
          console.error("Unexpected API response format:", response.data);
          setServices([]);
          setFilteredServices([]); // Ensure it's always an array
        }
      } catch (error) {
        console.error("Error fetching services:", error);
        setServices([]);
        setFilteredServices([]); // Handle error cases properly
      } finally {
        setLoading(false);
      }
    };
    fetchServices();
  }, []);

  // Search, filter, and sort services
  useEffect(() => {
    const timeout = setTimeout(() => {
      let updatedServices = services.filter((service) =>
        service.name.toLowerCase().includes(search.toLowerCase())
      );

      if (category !== "All") {
        updatedServices = updatedServices.filter(
          (service) => service.category === category
        );
      }

      if (location && location !== "All") {
        updatedServices = updatedServices.filter(
          (service) => service.location === location
        );
      }

      // Sort by availability first (available services on top)
      updatedServices.sort((a, b) => {
        if (a.available === b.available) return 0;
        return a.available ? -1 : 1;
      });

      // Apply additional sorting options
      if (sortOption === "priceLow") {
        updatedServices.sort((a, b) => a.price - b.price);
      } else if (sortOption === "priceHigh") {
        updatedServices.sort((a, b) => b.price - a.price);
      } else if (sortOption === "rating") {
        updatedServices.sort((a, b) => b.rating - a.rating);
      }

      setFilteredServices(updatedServices);
    }, 300);

    return () => clearTimeout(timeout);
  }, [search, services, category, location, sortOption]);

  // Toggle favorite
  const toggleFavorite = (serviceId) => {
    setFavorites((prev) =>
      prev.includes(serviceId)
        ? prev.filter((id) => id !== serviceId)
        : [...prev, serviceId]
    );
  };
  const handleEmergencyClick = () => {
    navigate("/emergency-services");
  };
  // const handleBookNow = (serviceName) => {
  //   if (!serviceName) {
  //     console.error("Service ID is missing!");
  //     return;
  //   }
  //   navigate(`/booking/${serviceName}`);
  // };

  return (
    <div className="home-page">
      {/* 🔥 Hero Section */}
      <div className="hero-section">
        <h1>Find the Best Local Services Near You</h1>
        <p>
          Browse trusted professionals for home, health, and automotive needs.
        </p>
        <button className="explore-btn" onClick={() => navigate("/explore")}>
          Explore Now 🚀
        </button>
        <button
          className="service-btn"
          onClick={() => navigate("/service-requirement")}
        >
          Service Based on Requirement
        </button>
        <button onClick={handleEmergencyClick} className="emergency-btn">
          Emergency Service Mode
        </button>
      </div>

      {/* 🔍 Search & Filters */}
      <div className="filters">
        <input
          type="text"
          className="search-bar"
          placeholder="Search for services..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="filter-dropdown"
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="All">All Categories</option>
          <option value="Home Services">Home Services</option>
          <option value="Automotive">Automotive</option>
          <option value="Health & Beauty">Health & Beauty</option>
        </select>
        <select
          className="filter-dropdown"
          onChange={(e) => setLocation(e.target.value)}
        >
          <option value="All">All Locations</option>
          <option value="Delhi">Delhi</option>
          <option value="Mumbai">Mumbai</option>
          <option value="Bangalore">Bangalore</option>
          <option value="Azamgarh">Azamgarh</option>
          <option value="Gorakhpur">Gorakhpur</option>
          <option value="Noida">Noida</option>
          <option value="Lucknow">Lucknow</option>
          <option value="Varanasi">Varanasi</option>
          <option value="Kanpur">Kanpur</option>
          <option value="Agra">Agra</option>
          <option value="Prayagraj">Prayagraj</option>
          <option value="Meerut">Meerut</option>
          <option value="Jhansi">Jhansi</option>
        </select>
        <select
          className="sort-dropdown"
          onChange={(e) => setSortOption(e.target.value)}
        >
          <option value="default">Sort By</option>
          <option value="priceLow">Price: Low to High</option>
          <option value="priceHigh">Price: High to Low</option>
          <option value="rating">Rating</option>
        </select>
      </div>

      {/* 🔄 Loading Indicator */}
      {loading ? <div className="loading">Loading services...</div> : null}

      {/* 📋 Services List */}
      <div className="services-grid">
        {filteredServices.map((service) => {
          // Normalize service name for icon mapping
          const serviceKey = service.name.trim().toLowerCase();
          return (
            <div key={service._id} className="service-card">
              <div className="service-icon">
                {serviceIcons[serviceKey] || <FaTools />} {/* Fallback icon */}
              </div>
              <h2 className="service-name">{service.name}</h2>
              <p className="service-location">Location📍 {service.location}</p>
              <div className="button-group">
                <button
                  className="view-details-btn"
                  onClick={() => setSelectedService(service)}
                >
                  View Details
                </button>
                <button
                  className="book-now-btn"
                  onClick={() => navigate(`/book/${service.name}`)}
                >
                  Book Now
                </button>
              </div>
              <button
                className="favorite-btn"
                onClick={() => toggleFavorite(service._id)}
              >
                {favorites.includes(service._id)
                  ? "❤️ Remove Favorite"
                  : "🤍 Add to Favorites"}
              </button>
            </div>
          );
        })}
      </div>

      {/* 📌 Modal for Viewing Service Details */}
      {selectedService && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>{selectedService.name}</h2>
            <div className="modal-icon">
              {serviceIcons[selectedService.name.toLowerCase()] || <FaTools />}
            </div>
            <p className="modal-description">{selectedService.description}</p>
            <p className="modal-category">
              Category: {selectedService.category}
            </p>
            <p className="modal-price">Price: ${selectedService.price}</p>
            <p className="modal-rating">Rating: ⭐ {selectedService.rating}</p>
            <p className="modal-availability">
              Availability:{" "}
              <span
                className={`availability-badge ${
                  selectedService.available ? "available" : "unavailable"
                }`}
              >
                {selectedService.available ? "Available" : "Unavailable"}
              </span>
            </p>
            <button
              className="close-btn"
              onClick={() => setSelectedService(null)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;
