import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "../Style/Bookings.css"; // Import advanced CSS

const Bookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate(); // Initialize useNavigate

  //  Fetch bookings from backend
  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/bookings");
        setBookings(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching bookings:", error);
        setLoading(false);
      }
    };

    fetchBookings();
  }, []);

  //  Cancel booking
  const cancelBooking = async (id) => {
    if (window.confirm("Are you sure you want to cancel this booking?")) {
      try {
        await axios.delete(`http://localhost:5000/api/bookings/${id}`);
        setBookings(bookings.filter((booking) => booking._id !== id));
      } catch (error) {
        console.error("Error canceling booking:", error);
      }
    }
  };

  //  Mark booking as completed
  const markAsCompleted = async (id) => {
    if (
      window.confirm("Are you sure you want to mark this booking as completed?")
    ) {
      try {
        const response = await axios.put(
          `http://localhost:5000/api/bookings/${id}/complete`
        );
        // Update the booking status in the UI
        console.log("Booking marked as completed:", response.data);

        setBookings((prevBookings) =>
          prevBookings.map((booking) =>
            booking._id === id ? { ...booking, status: "Completed" } : booking
          )
        );
      } catch (error) {
        console.error("Error marking booking as completed:", error);
      }
    }
  };

  //  Redirect to feedback form
  const handleFeedback = (bookingId) => {
    navigate(`/feedback/${bookingId}`); // Redirect to feedback form with booking ID
  };

  return (
    <div className="bookings-container">
      <h2>Your Bookings</h2>

      {loading ? (
        <p className="loading">Loading bookings...</p>
      ) : bookings.length === 0 ? (
        <p className="no-bookings">No bookings found.</p>
      ) : (
        <div className="bookings-list">
          {bookings.map((booking) => (
            <div key={booking._id} className="booking-card">
              <h3>{booking.serviceName}</h3>
              <p>Date: {booking.date}</p>
              <p>Time: {booking.time}</p>
              <p>Address: {booking.address}</p>
              <span
                className={`status ${
                  booking.status?.toLowerCase() || "pending"
                }`}
              >
                {booking.status || "Pending"}
              </span>
              {booking.status !== "Completed" && (
                <>
                  <button
                    className="cancel-btn"
                    onClick={() => cancelBooking(booking._id)}
                  >
                    Cancel
                  </button>
                  <button
                    className="complete-btn"
                    onClick={() => markAsCompleted(booking._id)}
                  >
                    Mark as Completed
                  </button>
                </>
              )}
              {/* Feedback Button */}
              {booking.status === "Completed" && (
                <button
                  className="feedback-btn"
                  onClick={() => handleFeedback(booking._id)}
                >
                  Give Feedback
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Bookings;
