import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../Style/CreateProviderID.css"; // Import the CSS file

const CreateProviderID = () => {
  const [provider, setProvider] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    experience: "",
    rating: "",
    servicesOffered: "",
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;

    // Validate rating to be between 1 and 5
    if (name === "rating") {
      const ratingValue = parseInt(value, 10);
      if (ratingValue < 1 || ratingValue > 5) {
        alert("Rating must be between 1 and 5.");
        return; // Prevent updating the state with invalid rating
      }
    }

    setProvider({ ...provider, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:5000/api/providers",
        provider
      );
      if (response.data) {
        alert("Provider ID created successfully!");
        navigate("/home"); // Redirect to home page
      }
    } catch (error) {
      console.error("Error creating provider:", error);
      alert("Failed to create provider. Please try again.");
    }
  };

  return (
    <div className="create-provider-container">
      <h2>Create Provider ID</h2>
      <form onSubmit={handleSubmit}>
        <label>Name</label>
        <input
          type="text"
          name="name"
          value={provider.name}
          onChange={handleChange}
          required
        />

        <label>Email</label>
        <input
          type="email"
          name="email"
          value={provider.email}
          onChange={handleChange}
          required
        />

        <label>Phone</label>
        <input
          type="text"
          name="phone"
          value={provider.phone}
          onChange={handleChange}
          required
        />

        <label>Address</label>
        <input
          type="text"
          name="address"
          value={provider.address}
          onChange={handleChange}
          required
        />

        <label>Experience</label>
        <input
          type="number"
          name="experience"
          value={provider.experience}
          onChange={handleChange}
          required
        />

        <label>Services Offered</label>
        <input
          type="text"
          name="servicesOffered"
          value={provider.servicesOffered}
          onChange={handleChange}
          required
        />

        <button type="submit">Create Provider ID</button>
      </form>
    </div>
  );
};

export default CreateProviderID;
