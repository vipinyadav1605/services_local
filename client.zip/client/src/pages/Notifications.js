import React, { useState } from "react";
import "../Style/Notifications.css";
import { FaBell, FaCheckCircle, FaTrashAlt } from "react-icons/fa";

const Notifications = () => {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      message: "New service request received!",
      type: "info",
      read: false,
    },
    {
      id: 2,
      message: "Payment received successfully.",
      type: "success",
      read: false,
    },
    {
      id: 3,
      message: "Service completed. Please leave a review.",
      type: "alert",
      read: true,
    },
  ]);

  const markAsRead = (id) => {
    setNotifications(
      notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const deleteNotification = (id) => {
    setNotifications(notifications.filter((n) => n.id !== id));
  };

  return (
    <div className="notifications-page">
      <div className="notifications-container">
        <h2>
          <FaBell /> Notifications
        </h2>
        <p>Check your latest notifications.</p>

        {notifications.length === 0 ? (
          <p className="no-notifications">No new notifications.</p>
        ) : (
          <ul className="notifications-list">
            {notifications.map(({ id, message, type, read }) => (
              <li
                key={id}
                className={`notification-card ${
                  read ? "read" : "unread"
                } ${type}`}
              >
                <span>{message}</span>
                <div className="notification-actions">
                  {!read && (
                    <button
                      className="mark-read"
                      onClick={() => markAsRead(id)}
                    >
                      <FaCheckCircle /> Mark as Read
                    </button>
                  )}
                  <button
                    className="delete"
                    onClick={() => deleteNotification(id)}
                  >
                    <FaTrashAlt /> Delete
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Notifications;
