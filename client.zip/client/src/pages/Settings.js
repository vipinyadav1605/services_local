import React, { useState } from "react";
import Switch from "../components/ui/Switch";
import Input from "../components/ui/Input";
import Button from "../components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/Card";
import "../Style/Settings.css";

const Settings = () => {
  const [profile, setProfile] = useState({
    name: "John Doe",
    email: "johndoe@example.com",
    password: "",
    profilePicture: null,
  });

  const [notifications, setNotifications] = useState({
    email: true,
    push: false,
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Simulate saving profile data to the backend
  const saveProfile = async () => {
    setLoading(true);
    setError("");
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));
      console.log("Profile saved:", profile);
      alert("Profile updated successfully!");
    } catch (err) {
      setError("Failed to save profile. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Simulate saving notification preferences to the backend
  const saveNotifications = async () => {
    setLoading(true);
    setError("");
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));
      console.log("Notifications saved:", notifications);
      alert("Notification preferences updated successfully!");
    } catch (err) {
      setError("Failed to save notifications. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleProfileChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleProfilePictureChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfile({ ...profile, profilePicture: URL.createObjectURL(file) });
    }
  };

  const handleNotificationChange = (type) => {
    setNotifications({ ...notifications, [type]: !notifications[type] });
  };

  const handleDeleteAccount = async () => {
    if (window.confirm("Are you sure you want to delete your account?")) {
      setLoading(true);
      setError("");
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000));
        console.log("Account deleted");
        alert("Account deleted successfully!");
      } catch (err) {
        setError("Failed to delete account. Please try again.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="st-container">
      <h2 className="st-title">⚙️ Settings</h2>

      {/* Profile Settings */}
      <Card className="st-card">
        <CardHeader>
          <CardTitle className="st-card-title">Profile Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="st-profile-picture-container">
            <img
              src={profile.profilePicture || "https://via.placeholder.com/150"}
              alt="Profile"
              className="st-profile-picture"
            />
            <input
              type="file"
              accept="image/*"
              onChange={handleProfilePictureChange}
              className="st-profile-picture-upload"
            />
          </div>
          <Input
            className="st-input"
            label="Name"
            name="name"
            value={profile.name}
            onChange={handleProfileChange}
          />
          <Input
            className="st-input"
            label="Email"
            name="email"
            type="email"
            value={profile.email}
            onChange={handleProfileChange}
          />
          <Input
            className="st-input"
            label="New Password"
            name="password"
            type="password"
            value={profile.password}
            onChange={handleProfileChange}
          />
          <Button
            className="st-button"
            onClick={saveProfile}
            disabled={loading}
          >
            {loading ? "Saving..." : "Save Changes"}
          </Button>
          {error && <p className="st-error">{error}</p>}
        </CardContent>
      </Card>

      {/* Security Settings */}
      <Card className="st-card">
        <CardHeader>
          <CardTitle className="st-card-title">Security Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="st-switch-container">
            <span>Two-Factor Authentication</span>
            <Switch
              checked={notifications.email}
              onCheckedChange={() => handleNotificationChange("email")}
            />
          </div>
        </CardContent>
      </Card>

      {/* Notification Preferences */}
      <Card className="st-card">
        <CardHeader>
          <CardTitle className="st-card-title">
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="st-switch-container">
            <span>Email Notifications</span>
            <Switch
              checked={notifications.email}
              onCheckedChange={() => handleNotificationChange("email")}
            />
          </div>
          <div className="st-switch-container">
            <span>Push Notifications</span>
            <Switch
              checked={notifications.push}
              onCheckedChange={() => handleNotificationChange("push")}
            />
          </div>
          <Button
            className="st-button"
            onClick={saveNotifications}
            disabled={loading}
          >
            {loading ? "Saving..." : "Save Preferences"}
          </Button>
          {error && <p className="st-error">{error}</p>}
        </CardContent>
      </Card>

      {/* Account Management */}
      <Card className="st-card">
        <CardHeader>
          <CardTitle className="st-card-title">Account Management</CardTitle>
        </CardHeader>
        <CardContent>
          <Button
            className="st-button st-button-danger"
            onClick={handleDeleteAccount}
            disabled={loading}
          >
            {loading ? "Deleting..." : "Delete Account"}
          </Button>
          {error && <p className="st-error">{error}</p>}
        </CardContent>
      </Card>
    </div>
  );
};

export default Settings;
