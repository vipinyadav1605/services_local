import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../Style/ServiceRequirementForm.module.css"; // Import CSS Module

const ServiceRequirementForm = () => {
  const [service, setService] = useState("");
  const [location, setLocation] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:5000/api/match-providers",
        {
          service,
          location,
        }
      );
      navigate("/matching-providers", { state: { providers: response.data } });
    } catch (error) {
      console.error("Error submitting form:", error);
    }
  };

  return (
    <div className={styles.formContainer}>
      <h2>Service Requirement Form</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Service:
          <input
            type="text"
            value={service}
            onChange={(e) => setService(e.target.value)}
            required
          />
        </label>
        <label>
          Location:
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            required
          />
        </label>
        <button type="submit">Find Providers</button>
      </form>
    </div>
  );
};

export default ServiceRequirementForm;
