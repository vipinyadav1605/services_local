import React from "react";
import { useNavigate } from "react-router-dom";
import "../Style/Preferences.css";

const PreferencesSaved = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate("/preferences");
  };

  return (
    <div className="preferences-container">
      <h2 className="preferences-title">✅ Preferences Saved</h2>
      <p className="preferences-description">
        Your preferences have been successfully updated.
      </p>
      <button className="save-button" onClick={handleGoBack}>
        Go Back to Preferences
      </button>
    </div>
  );
};

export default PreferencesSaved;
