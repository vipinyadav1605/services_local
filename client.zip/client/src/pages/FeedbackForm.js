import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../Style/FeedbackForm.module.css"; // Import CSS Module

const FeedbackForm = () => {
  const { bookingId } = useParams(); // Get booking ID from URL
  const navigate = useNavigate();
  const [feedback, setFeedback] = useState("");
  const [rating, setRating] = useState(5);
  const [serviceName, setServiceName] = useState(""); // State to store service name

  // Fetch booking details (including service name) when the component mounts
  useEffect(() => {
    const fetchBookingDetails = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/api/bookings/${bookingId}`
        );
        setServiceName(response.data.serviceName); // Set the service name
      } catch (error) {
        console.error("Error fetching booking details:", error);
        alert("Failed to fetch booking details. Please try again.");
      }
    };

    fetchBookingDetails();
  }, [bookingId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`http://localhost:5000/api/feedback`, {
        bookingId,
        feedback,
        rating,
      });
      alert("Feedback submitted successfully!");
      navigate("/bookings"); // Redirect back to bookings page
    } catch (error) {
      console.error("Error submitting feedback:", error);
      alert("Failed to submit feedback. Please try again.");
    }
  };

  return (
    <div className={styles.feedbackContainer}>
      {/* Display the service name in the title */}
      <h2>User Feedback for {serviceName || "Service"}</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Feedback:
          <textarea
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            required
          />
        </label>
        <label>
          Rating:
          <select
            value={rating}
            onChange={(e) => setRating(e.target.value)}
            required
          >
            <option value={1}>1 - Poor</option>
            <option value={2}>2 - Fair</option>
            <option value={3}>3 - Good</option>
            <option value={4}>4 - Very Good</option>
            <option value={5}>5 - Excellent</option>
          </select>
        </label>
        <button type="submit">Submit Feedback</button>
      </form>
    </div>
  );
};

export default FeedbackForm;
