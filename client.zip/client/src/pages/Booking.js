import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import "../Style/Booking.css"; // Uncomment if you have CSS

const Booking = () => {
  const { serviceName } = useParams(); // Get service name from URL
  const navigate = useNavigate();
  const [bookingDetails, setBookingDetails] = useState({
    name: "",
    phone: "",
    date: "",
    time: "",
    address: "",
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  // Handle input changes
  const handleChange = (e) => {
    setBookingDetails({ ...bookingDetails, [e.target.name]: e.target.value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post("http://localhost:5000/api/bookings", {
        serviceName,
        ...bookingDetails,
      });

      setMessage("Booking confirmed! We will contact you soon.");
      setTimeout(() => {
        navigate("/"); // Redirect to home after booking
      }, 3000);
    } catch (error) {
      console.error("Booking failed:", error);
      setMessage("Failed to book service. Please try again.");
    }

    setLoading(false);
  };

  return (
    <div className="booking-container">
      <h2>Book {serviceName}</h2>

      {message ? (
        <p className="booking-message">{message}</p>
      ) : (
        <form className="booking-form" onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            required
            value={bookingDetails.name}
            onChange={handleChange}
          />
          <input
            type="tel"
            name="phone"
            placeholder="Phone Number"
            required
            value={bookingDetails.phone}
            onChange={handleChange}
          />
          <input
            type="date"
            name="date"
            required
            value={bookingDetails.date}
            onChange={handleChange}
          />
          <input
            type="time"
            name="time"
            required
            value={bookingDetails.time}
            onChange={handleChange}
          />
          <textarea
            name="address"
            placeholder="Enter your address"
            required
            value={bookingDetails.address}
            onChange={handleChange}
          ></textarea>
          <button type="submit" disabled={loading}>
            {loading ? "Booking..." : "Confirm Booking"}
          </button>
        </form>
      )}
    </div>
  );
};

export default Booking;
