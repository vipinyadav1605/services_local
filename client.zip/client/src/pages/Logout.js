import React from "react";
import { useNavigate } from "react-router-dom";
import "../Style/Logout.css";

const Logout = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Remove all items from localStorage (same as in Profile component)
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    localStorage.removeItem("role");
    localStorage.removeItem("user");

    // Redirect to the login page
    navigate("/login");
  };

  return (
    <div className="logout-container">
      <div className="logout-card">
        <h2>Are you sure you want to logout?</h2>
        <p>You will need to log in again to access your account.</p>

        <div className="logout-buttons">
          <button className="cancel-btn" onClick={() => navigate(-1)}>
            Cancel
          </button>
          <button className="logout-btn" onClick={handleLogout}>
            Confirm Logout
          </button>
        </div>
      </div>
    </div>
  );
};

export default Logout;
