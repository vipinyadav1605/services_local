import React, { useState } from "react";
import "../Style/Support.css"; // Import advanced CSS

const Support = () => {
  const [query, setQuery] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [faqs, setFaqs] = useState([
    {
      question: "How do I reset my password?",
      answer: "Go to settings > Change Password.",
      open: false,
    },
    {
      question: "How can I contact customer service?",
      answer: "You can email us at support@example.com",
      open: false,
    },
    {
      question: "Where can I track my orders?",
      answer: "Go to your profile > Orders to check the status.",
      open: false,
    },
  ]);
  const [liveChat, setLiveChat] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [message, setMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim() === "") return;
    setSubmitted(true);
  };

  const toggleFaq = (index) => {
    setFaqs(
      faqs.map((faq, i) => (i === index ? { ...faq, open: !faq.open } : faq))
    );
  };

  const handleChatSend = (e) => {
    e.preventDefault();
    if (message.trim() === "") return;
    setChatMessages([...chatMessages, { text: message, user: "You" }]);
    setMessage("");
    // Simulating a bot response after 1.5 seconds
    setTimeout(() => {
      setChatMessages([
        ...chatMessages,
        { text: message, user: "You" },
        { text: "We'll get back to you soon!", user: "Support" },
      ]);
    }, 1500);
  };

  return (
    <div className="support-container">
      <h2>Customer Support</h2>

      {/* FAQ Section */}
      <div className="faq-section">
        <h3>Frequently Asked Questions</h3>
        {faqs.map((faq, index) => (
          <div key={index} className="faq">
            <div className="faq-question" onClick={() => toggleFaq(index)}>
              {faq.question} <span>{faq.open ? "▲" : "▼"}</span>
            </div>
            {faq.open && <p className="faq-answer">{faq.answer}</p>}
          </div>
        ))}
      </div>

      {/* Support Form */}
      {!submitted ? (
        <div className="query-section">
          <p>Have an issue? Submit your query below:</p>
          <form onSubmit={handleSubmit}>
            <textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Describe your issue..."
            ></textarea>
            <button type="submit">Submit</button>
          </form>
        </div>
      ) : (
        <div className="support-success">
          <h3>Thank you for reaching out! 🎉</h3>
          <p>Our team will get back to you soon.</p>
        </div>
      )}

      {/* Live Chat Support */}
      <div className="live-chat">
        <button onClick={() => setLiveChat(!liveChat)}>
          {liveChat ? "Close Live Chat" : "Open Live Chat"}
        </button>

        {liveChat && (
          <div className="chat-box">
            <div className="chat-messages">
              {chatMessages.map((msg, index) => (
                <div
                  key={index}
                  className={`chat-message ${
                    msg.user === "You" ? "user" : "support"
                  }`}
                >
                  <strong>{msg.user}:</strong> {msg.text}
                </div>
              ))}
            </div>
            <form onSubmit={handleChatSend} className="chat-form">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your message..."
              />
              <button type="submit">Send</button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default Support;
