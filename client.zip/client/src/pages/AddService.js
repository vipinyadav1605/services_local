import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../Style/AddService.css";

const AddService = () => {
  const [service, setService] = useState({
    name: "",
    category: "",
    description: "",
    price: "",
    location: "",
    available: true,
    image: null,
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setService({ ...service, [name]: value });
  };

  const handleImageChange = (e) => {
    setService({ ...service, image: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("name", service.name);
    formData.append("category", service.category);
    formData.append("description", service.description);
    formData.append("price", service.price);
    formData.append("location", service.location);
    formData.append("available", service.available);
    if (service.image) {
      formData.append("image", service.image);
    }

    try {
      const response = await fetch("http://localhost:5000/api/services", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        alert("Service added successfully!");
        setService({
          name: "",
          category: "",
          description: "",
          price: "",
          location: "",
          available: true,
          image: null,
        });
        navigate("/home");
      } else {
        const errorData = await response.json();
        alert(`Failed to add service: ${errorData.error || "Unknown error"}`);
      }
    } catch (error) {
      console.error("Error adding service:", error);
      alert("An error occurred while adding the service. Please try again.");
    }
  };

  return (
    <div className="add-service-container">
      <h2>Add New Service</h2>
      <p>Fill out the form to add a new service.</p>

      <form onSubmit={handleSubmit} className="service-form">
        <label>Service Name</label>
        <input
          type="text"
          name="name"
          value={service.name}
          onChange={handleChange}
          required
          placeholder="Enter service name"
        />

        <label>Category</label>
        <select
          name="category"
          value={service.category}
          onChange={handleChange}
          required
        >
          <option value="">Select Category</option>
          <option value="Cleaning">Cleaning</option>
          <option value="Plumbing">Plumbing</option>
          <option value="Electrical">Electrical</option>
          <option value="Home Repair">Home Repair</option>
          <option value="Beauty & Salon">Beauty & Salon</option>
          <option value="Carpentry">Carpentry</option>
          <option value="AC Repair">AC Repair</option>
          <option value="Home Tutoring">Home Tutoring</option>
          <option value="Fitness Trainer">Fitness Trainer</option>
          <option value="Legal Consultation">Legal Consultation</option>
          <option value="Event Planning">Event Planning</option>
        </select>

        <label>Description</label>
        <textarea
          name="description"
          value={service.description}
          onChange={handleChange}
          required
          placeholder="Describe your service..."
        />

        <label>Price (in INR)</label>
        <input
          type="number"
          name="price"
          value={service.price}
          onChange={handleChange}
          required
          placeholder="Enter price"
        />

        <label>Location (City Name)</label>
        <input
          type="text"
          name="location"
          value={service.location}
          onChange={handleChange}
          required
          placeholder="Enter service location"
        />

        <label>Availability</label>
        <select
          name="available"
          value={service.available}
          onChange={handleChange}
          required
        >
          <option value={true}>Available</option>
          <option value={false}>Not Available</option>
        </select>

        <label>Upload Image</label>
        <input type="file" onChange={handleImageChange} accept="image/*" />

        <button type="submit" className="submit-button">
          Add Service
        </button>
      </form>
    </div>
  );
};

export default AddService;
