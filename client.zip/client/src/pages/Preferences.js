import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../Style/Preferences.css";

const Preferences = () => {
  const [preferences, setPreferences] = useState({
    theme: "light",
    language: "English",
    notifications: true,
  });

  const [darkMode, setDarkMode] = useState(false); // Add darkMode state
  const navigate = useNavigate();

  // Load preferences from localStorage when the component mounts
  useEffect(() => {
    const savedPreferences = JSON.parse(localStorage.getItem("preferences"));
    if (savedPreferences) {
      setPreferences(savedPreferences);
      // Set darkMode based on saved theme preference
      setDarkMode(savedPreferences.theme === "dark");
    }
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const updatedValue = type === "checkbox" ? checked : value;

    setPreferences({
      ...preferences,
      [name]: updatedValue,
    });

    // Update darkMode state when theme changes
    if (name === "theme") {
      setDarkMode(updatedValue === "dark");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Preferences Saved:", preferences);

    // Save preferences to localStorage
    localStorage.setItem("preferences", JSON.stringify(preferences));

    // Navigate to the confirmation page
    navigate("/preferences-saved");
  };

  return (
    <div className={`preferences-container ${darkMode ? "dark-mode" : ""}`}>
      <h2 className="preferences-title">⚙️ Preferences</h2>
      <p className="preferences-description">
        Customize your app experience by updating your preferences.
      </p>

      <form className="preferences-form" onSubmit={handleSubmit}>
        {/* Theme Selection */}
        <div className="form-group">
          <label className="form-label">Choose Theme</label>
          <select
            name="theme"
            value={preferences.theme}
            onChange={handleChange}
            className="form-select"
          >
            <option value="light">Light Mode</option>
            <option value="dark">Dark Mode</option>
          </select>
        </div>

        {/* Language Selection */}
        <div className="form-group">
          <label className="form-label">Select Language</label>
          <select
            name="language"
            value={preferences.language}
            onChange={handleChange}
            className="form-select"
          >
            <option value="English">English</option>
            <option value="Hindi">Hindi</option>
            <option value="Spanish">Spanish</option>
            <option value="French">French</option>
          </select>
        </div>

        {/* Notifications */}
        <div className="form-group">
          <label className="checkbox-label">
            <input
              type="checkbox"
              name="notifications"
              checked={preferences.notifications}
              onChange={handleChange}
              className="form-checkbox"
            />
            <span className="checkbox-custom"></span>
            Enable Notifications
          </label>
        </div>

        {/* Save Button */}
        <button type="submit" className="save-button">
          Save Preferences
        </button>
      </form>
    </div>
  );
};

export default Preferences;
