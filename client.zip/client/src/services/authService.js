const API_URL = "http://localhost:5000/api/auth";

// Login API
export const login = async (userData) => {
  try {
    const response = await fetch(`${API_URL}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userData),
    });

    const data = await response.json(); // Parse JSON response

    const textResponse = await response.text(); // Get response as text
    console.log("Raw Response:", textResponse); // Debugging

    // const data = JSON.parse(textResponse); // Convert to JSON
    if (!response.ok) {
      throw new Error(data.message || "Login failed"); // Use backend error message
    }

    return data;
  } catch (error) {
    throw new Error(error.message || "Something went wrong");
  }
};

// Register API
export const register = async (userData) => {
  try {
    const response = await fetch(`${API_URL}/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userData),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Registration failed");
    }

    return data;
  } catch (error) {
    throw new Error(error.message || "Something went wrong");
  }
};
