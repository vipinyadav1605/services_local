// import {
//   BrowserRouter as Router,
//   Routes,
//   Route,
//   Navigate,
// } from "react-router-dom";
// import Home from "./pages/Home";
// import { useLocation } from "react-router-dom";

// import Login from "./pages/Login";
// import Register from "./pages/Register";
// import Services from "./pages/Services";
// import Chat from "./pages/Chat";
// import Navbar from "./components/Navbar";
// import SocketChat from "./components/SocketChat";
// import Bookings from "./pages/Bookings";
// import Payment from "./pages/Payment";
// import Support from "./pages/Support";
// import GeoSearch from "./pages/GeoSearch";
// import Profile from "./pages/Profile";
// import Booking from "./pages/Booking";
// import Explore from "./pages/Explore";
// import ForgotPassword from "./pages/ForgotPassword";

// // Protect Routes: Only allow access if the user is logged in
// const PrivateRoute = ({ children }) => {
//   const token = localStorage.getItem("token");
//   return token ? children : <Navigate to="/login" />;
// };

// // Auth Routes: If logged in, redirect to services page
// const AuthRoute = ({ children }) => {
//   const token = localStorage.getItem("token");
//   return token ? <Navigate to="/services" /> : children;
// };

// function Appbase() {
//   const location = useLocation(); // Get current route

//   // Define routes where Navbar should be hidden
//   const hideNavbarRoutes = ["/login", "/register"];

//   return (
//     <>
//       {!hideNavbarRoutes.includes(location.pathname) && <Navbar />}

//       <Routes>
//         <Route path="/" element={<Navigate to="/login" />} />{" "}
//         {/* Redirect root to login */}
//         <Route
//           path="/login"
//           element={
//             <AuthRoute>
//               <Login />
//             </AuthRoute>
//           }
//         />
//         <Route
//           path="/register"
//           element={
//             <AuthRoute>
//               <Register />
//             </AuthRoute>
//           }
//         />
//         <Route path="/forgot-password" element={<ForgotPassword />} />
//         {/* Protected Routes (Require Authentication) */}
//         <Route
//           path="/home"
//           element={
//             <PrivateRoute>
//               <Home />
//             </PrivateRoute>
//           }
//         />
//         <Route
//           path="/services"
//           element={
//             // <PrivateRoute>
//             <Services />
//             // {/* </PrivateRoute> */}
//           }
//         />
//         <Route
//           path="/chat"
//           element={
//             <PrivateRoute>
//               <Chat />
//             </PrivateRoute>
//           }
//         />
//         <Route
//           path="/socket-chat"
//           element={
//             <PrivateRoute>
//               <SocketChat />
//             </PrivateRoute>
//           }
//         />
//         <Route
//           path="/profile"
//           element={
//             <PrivateRoute>
//               <Profile />
//             </PrivateRoute>
//           }
//         />
//         <Route
//           path="/bookings"
//           element={
//             <PrivateRoute>
//               <Bookings />
//             </PrivateRoute>
//           }
//         />
//         <Route
//           path="/payment"
//           element={
//             <PrivateRoute>
//               <Payment />
//             </PrivateRoute>
//           }
//         />
//         <Route
//           path="/support"
//           element={
//             <PrivateRoute>
//               <Support />
//             </PrivateRoute>
//           }
//         />
//         <Route
//           path="/geo-search"
//           element={
//             <PrivateRoute>
//               <GeoSearch />
//             </PrivateRoute>
//           }
//         />
//         <Route
//           path="/book/:serviceName"
//           element={
//             <PrivateRoute>
//               <Booking />
//             </PrivateRoute>
//           }
//         />
//         <Route
//           path="/explore"
//           element={
//             <PrivateRoute>
//               <Explore />
//             </PrivateRoute>
//           }
//         />
//       </Routes>
//     </>
//   );
// }

// function App() {
//   return (
//     <Router>
//       <Appbase />
//     </Router>
//   );
// }

// export default App;

import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import { useState, useEffect, useMemo } from "react";
import { useLocation } from "react-router-dom";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Services from "./pages/Services";
import Chat from "./pages/Chat";
import Navbar from "./components/Navbar";
import SocketChat from "./components/SocketChat";
import Bookings from "./pages/Bookings";
import Payment from "./pages/Payment";
import Support from "./pages/Support";
import GeoSearch from "./pages/GeoSearch";
import Profile from "./pages/Profile";
import Booking from "./pages/Booking";
import Explore from "./pages/Explore";
import ForgotPassword from "./pages/ForgotPassword";
import Settings from "./pages/Settings";
import AddService from "./pages/AddService";
import ManageServices from "./pages/ManageServices";
import Notifications from "./pages/Notifications";
import Preferences from "./pages/Preferences";
import PreferencesSaved from "./pages/PreferencesSaved";
import Logout from "./pages/Logout";
import ProviderProfile from "./pages/ProviderProfile";
import ProvidersList from "./pages/ProvidersList";
import ProvidersForService from "./pages/ProvidersForService";
import CreateProviderID from "./pages/CreateProviderID";
import { ThemeProvider } from "./Context/ThemeContext";
import CashOnService from "./pages/CashOnService"; // Import the new component
import FeedbackForm from "./pages/FeedbackForm"; // Import FeedbackForm
import ServiceRequirementForm from "./pages/ServiceRequirementForm";
import MatchingProviders from "./pages/MatchingProviders";
import EmergencyServices from "./pages/EmergencyServices";

const PrivateRoute = ({ children }) => {
  const [token, setToken] = useState(localStorage.getItem("token"));

  useEffect(() => {
    const handleStorageChange = () => {
      setToken(localStorage.getItem("token"));
    };
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  return token ? children : <Navigate to="/login" replace />;
};

const AuthRoute = ({ children }) => {
  const token = localStorage.getItem("token");
  return token ? <Navigate to="/home" replace /> : children;
};

function Appbase() {
  const location = useLocation();
  const hideNavbar = useMemo(
    () =>
      ["/login", "/register", "/forgot-password"].includes(location.pathname),
    [location.pathname]
  );

  return (
    <>
      {!hideNavbar && <Navbar />}
      <Routes>
        <Route
          path="/"
          element={
            <Navigate to={localStorage.getItem("token") ? "/home" : "/login"} />
          }
        />
        <Route
          path="/login"
          element={
            <AuthRoute>
              <Login />
            </AuthRoute>
          }
        />
        <Route
          path="/register"
          element={
            <AuthRoute>
              <Register />
            </AuthRoute>
          }
        />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        {/* Protected Routes */}
        <Route
          path="/home"
          element={
            <PrivateRoute>
              <Home />
            </PrivateRoute>
          }
        />
        <Route
          path="/services"
          element={
            <PrivateRoute>
              <Services />
            </PrivateRoute>
          }
        />
        <Route
          path="/chat"
          element={
            <PrivateRoute>
              <Chat />
            </PrivateRoute>
          }
        />
        <Route
          path="/socket-chat"
          element={
            <PrivateRoute>
              <SocketChat />
            </PrivateRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <PrivateRoute>
              <Profile />
            </PrivateRoute>
          }
        />
        <Route
          path="/bookings"
          element={
            <PrivateRoute>
              <Bookings />
            </PrivateRoute>
          }
        />
        <Route
          path="/payment"
          element={
            <PrivateRoute>
              <Payment />
            </PrivateRoute>
          }
        />
        <Route
          path="/support"
          element={
            <PrivateRoute>
              <Support />
            </PrivateRoute>
          }
        />
        <Route
          path="/geo-search"
          element={
            <PrivateRoute>
              <GeoSearch />
            </PrivateRoute>
          }
        />
        <Route
          path="/book/:serviceName"
          element={
            <PrivateRoute>
              <Booking />
            </PrivateRoute>
          }
        />
        <Route
          path="/explore"
          element={
            <PrivateRoute>
              <Explore />
            </PrivateRoute>
          }
        />
        <Route
          path="/settings"
          element={
            <PrivateRoute>
              <Settings />
            </PrivateRoute>
          }
        />
        <Route
          path="/add-service"
          element={
            <PrivateRoute>
              <AddService />
            </PrivateRoute>
          }
        />
        <Route
          path="/manage-services"
          element={
            <PrivateRoute>
              <ManageServices />
            </PrivateRoute>
          }
        />
        <Route
          path="/notifications"
          element={
            <PrivateRoute>
              <Notifications />
            </PrivateRoute>
          }
        />
        <Route
          path="/preferences"
          element={
            <PrivateRoute>
              <Preferences />
            </PrivateRoute>
          }
        />
        <Route
          path="/logout"
          element={
            <PrivateRoute>
              <Logout />
            </PrivateRoute>
          }
        />
        <Route path="/provider/:id" element={<ProviderProfile />} />
        <Route path="/provider/:providerId" element={<ProviderProfile />} />
        <Route path="/providers/:providerId" element={<ProvidersList />} />
        <Route path="/providers" element={<ProvidersList />} />
        <Route
          path="/providers-for-service/:serviceName"
          element={<ProvidersForService />}
        />
        <Route
          path="/service-requirement"
          element={<ServiceRequirementForm />}
        />
        <Route path="/matching-providers" element={<MatchingProviders />} />
        <Route path="/cash-on-service" element={<CashOnService />} />
        <Route path="/feedback/:bookingId" element={<FeedbackForm />} />{" "}
        {/* Add feedback route */}
        <Route path="/create-provider" element={<CreateProviderID />} />
        <Route path="/preferences-saved" element={<PreferencesSaved />} />
        <Route path="/emergency-services" element={<EmergencyServices />} />
      </Routes>
    </>
  );
}

function App() {
  return (
    <ThemeProvider>
      <Router>
        <Appbase />
      </Router>
    </ThemeProvider>
  );
}

export default App;
