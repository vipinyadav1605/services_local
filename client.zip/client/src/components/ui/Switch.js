import React from "react";

const Switch = ({ checked, onCheckedChange }) => {
  return (
    <input
      type="checkbox"
      checked={checked}
      onChange={(e) => onCheckedChange(e.target.checked)}
      className="cursor-pointer"
    />
  );
};

export default Switch;
