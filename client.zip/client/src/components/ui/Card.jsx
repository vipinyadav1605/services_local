import React from "react";

export const Card = ({ children }) => {
  return <div className="p-4 border rounded-lg shadow-md">{children}</div>;
};

export const CardHeader = ({ children }) => {
  return <div className="pb-2 border-b">{children}</div>;
};

export const CardTitle = ({ children }) => {
  return <h3 className="text-lg font-semibold">{children}</h3>;
};

export const CardContent = ({ children }) => {
  return <div className="pt-2">{children}</div>;
};
