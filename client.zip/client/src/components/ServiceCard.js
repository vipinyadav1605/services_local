import { Card, CardContent, Typography, Button } from "@mui/material";

function ServiceCard({ title, description, price }) {
  return (
    <Card sx={{ maxWidth: 345, margin: "auto", boxShadow: 3 }}>
      <CardContent>
        <Typography variant="h5">{title}</Typography>
        <Typography variant="body2">{description}</Typography>
        <Typography variant="h6">₹{price}</Typography>
        <Button variant="contained" sx={{ mt: 2 }} color="primary">
          Book Now
        </Button>
      </CardContent>
    </Card>
  );
}

export default ServiceCard;
