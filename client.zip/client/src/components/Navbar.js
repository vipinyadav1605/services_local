// export default Navbar;
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { FaCog } from "react-icons/fa";
import "../Style/Navbar.css";

const Navbar = () => {
  const [showSettings, setShowSettings] = useState(false);

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <img className="logo" src="/logo192.png" alt="Logo" />
        <Link to="/">Home</Link>
      </div>

      <div className="navbar-right">
        <Link to="/services">Services</Link>
        <Link to="/chat">Chat</Link>
        <Link to="/profile">Profile</Link>
        <Link to="/bookings">Bookings</Link>
        <Link to="/payment">Payments</Link>
        <Link to="/support">Support</Link>

        {/* Settings Dropdown */}
        <div className="settings-container">
          <button
            className="settings-icon"
            onClick={() => setShowSettings(!showSettings)}
          >
            <FaCog size={30} />
          </button>

          {showSettings && (
            <div className="settings-dropdown">
              <Link to="/settings" onClick={() => setShowSettings(false)}>
                Settings
              </Link>
              <Link to="/add-service" onClick={() => setShowSettings(false)}>
                Add New Service
              </Link>

              <Link
                to="/manage-services"
                onClick={() => setShowSettings(false)}
              >
                Manage Services
              </Link>
              <Link
                to="/create-provider"
                onClick={() => setShowSettings(false)}
              >
                Create Provider ID
              </Link>
              <Link to="/notifications" onClick={() => setShowSettings(false)}>
                Notifications
              </Link>
              <Link to="/preferences" onClick={() => setShowSettings(false)}>
                Preferences
              </Link>
              <Link to="/logout" onClick={() => setShowSettings(false)}>
                Logout
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
